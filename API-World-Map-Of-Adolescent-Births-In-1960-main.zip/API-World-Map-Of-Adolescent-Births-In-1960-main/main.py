import pygal
import csv
from countries import COUNTRIES
from country_codes import get_country_code
from pygal.maps.world import World
from pygal.style import LightColorizedStyle as LCS, RotateStyle as RS




filename = "/Users/tgiedraitis/Downloads/API_SP.ADO.TFRT_DS2_en_csv_v2_2602143/API_SP.ADO.TFRT_DS2_en_csv_v2_2602143.csv"
with open(filename) as f:
    reader = csv.reader(f)
    header_row = next(reader)
    #print(header_row)
    for index, column_header in enumerate(header_row):
        print(index, column_header)
        print(header_row)

    # Build a directory of population data
    cc_populations = {}
    for row in reader:
        if row[4] == "":
            continue
        country_name = row[0]
        births = int(float(row[4]))
        code = get_country_code(country_name)
        if code:
            cc_populations[code] = births
            print(code + ":"  + str(births))

        else:
            print("Error:", country_name)

    # Group the countries into 3 population levels
cc_births_1, cc_births_2, cc_births_3 = {}, {}, {}
for cc, birth in cc_populations.items():
    if birth < 50:
        cc_births_1[cc] = birth
    elif birth > 200 :
        cc_births_2[cc] = birth
    else:
        cc_births_3[cc] = birth

# See how many countries are in each level
print(len(cc_births_1), len(cc_births_2), len(cc_births_3))

wm_style = RS('#336699', base_style=LCS)
wm = World(style=wm_style)
wm.title = "Global Adolescent Births, by Country"
wm.add('0-50', cc_births_1)
wm.add('>200', cc_births_2)
wm.add('other', cc_births_3)
wm.add("1960", cc_populations)
wm.render_in_browser()
